# Spinify (Public) — Two‑Bot System (v1)

This repo contains **two Telegram bots**:

1) **@SpinifyLoginBot** — collects API_ID, API_HASH, phone, **keypad OTP**, and saves an **encrypted Telethon session string** for each user.
2) **@SpinifyAdsBot** — the main UI with join‑gate, Add Message (forwarded message only), Load Groups (paste up to 5 t.me links), fixed **30‑minute** interval, and **1 minute** delay between groups, Profile, Developer, Guide, Logout, and owner‑only `/broadcast`.

> Data store: **SQLite** by default (works great for a single server). For larger scale, set `DB_URL` to a Postgres URL and adjust `storage.py` accordingly.

---

## Quick start

1. **Python 3.10+** recommended.
2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Copy env and fill values:

```bash
cp .env.example .env
# edit .env in any editor
```

4. Run the **login bot** first (in one terminal):

```bash
python spinify_login_bot.py
```

5. Run the **main bot** (in another terminal):

```bash
python spinify_main_bot.py
```

> Both bots share the same `data/spinify.sqlite` and the same `ENCRYPTION_KEY` value.

---

## Environment variables

Edit `.env` (copied from `.env.example`):

- `LOGIN_BOT_TOKEN` — Bot token for **@SpinifyLoginBot**
- `MAIN_BOT_TOKEN` — Bot token for **@SpinifyAdsBot**
- `OWNER_ID` — Your Telegram user ID (for `/broadcast` and admin)
- `ENCRYPTION_KEY` — 64 hex characters (32 bytes) for AES/Fernet encryption
- `DB_PATH` — SQLite file path (default `data/spinify.sqlite`)
- `GATE_CHANNEL` — required channel handle, e.g. `@PhiloBots`
- `GATE_GROUP` — required group handle, e.g. `@YourGroup`
- `TIMEZONE` — e.g. `Asia/Kolkata`

---

## User flows

### Join‑gate
Main bot `/start` checks membership in **both** `GATE_CHANNEL` and `GATE_GROUP`. Only after both joined will the menu show.

### Login (via @SpinifyLoginBot)
1) `/start` → asks **API_ID**, **API_HASH**, **phone**  
2) Sends login code → user sees **numeric keypad** to enter OTP  
3) If 2FA enabled, asks for password  
4) Saves **encrypted** Telethon string session (linked to the user’s Telegram ID)

### Add Message
- User must **forward** the message they want to repeat. We store its **source chat id** + **message id**.
- (Copy mode can be added later; forwarding is safest and fastest.)

### Load Groups (links‑only, max 5)
- User pastes up to **5** Telegram links in **one message** (each on a new line):
  - `https://t.me/PublicGroupOrChannel`
  - `https://t.me/+InviteHash` or `https://t.me/joinchat/InviteHash`
- The system joins (if needed), validates posting rights, and saves the targets.

### Posting cadence
- **Every group** receives the selected post **every 30 minutes** (per‑target spacing).
- Global dispatcher posts to **one group per minute** (never blasts all at once).

---

## Systemd (optional)

Example units are in `systemd/`. After editing paths:

```bash
sudo cp systemd/spinify_login_bot.service /etc/systemd/system/
sudo cp systemd/spinify_main_bot.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now spinify_login_bot spinify_main_bot
```

---

## Notes

- This code uses **aiogram v2** (stable) and **Telethon**.
- Sessions are encrypted; **OTP/password are never stored**.
- The main bot **uses the user’s Telethon session** to join groups and forward posts.
- Channels typically require admin rights to post; the code checks and will skip if missing.
- Adjust rate limits if you scale to many users.
